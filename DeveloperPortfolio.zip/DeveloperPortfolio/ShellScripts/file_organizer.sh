#!/bin/bash
# Usage: ./file_organizer.sh <folder>
# Moves files into subfolders named after their extension
DIR="${1:-.}"

for f in "$DIR"/*; do
  [ -f "$f" ] || continue
  ext="${f##*.}"
  [ "$ext" = "$f" ] && ext="no_extension"
  mkdir -p "$DIR/$ext"
  mv "$f" "$DIR/$ext/"
  echo "Moved $(basename "$f") -> $ext/"
done
echo "Done organizing $DIR"
