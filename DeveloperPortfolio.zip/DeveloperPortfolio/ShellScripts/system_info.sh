#!/bin/bash
# Prints a quick system report
echo "===== System Report ====="
echo "User     : $(whoami)"
echo "Host     : $(hostname)"
echo "Date     : $(date)"
echo "Kernel   : $(uname -r)"
echo "Uptime   : $(uptime -p)"
echo "--- Memory ---"
free -h
echo "--- Disk ---"
df -h /
