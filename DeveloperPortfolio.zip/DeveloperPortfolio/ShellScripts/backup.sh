#!/bin/bash
# Usage: ./backup.sh <folder_to_backup> [destination_folder]
SRC="$1"
DEST="${2:-$HOME/backups}"

if [ -z "$SRC" ] || [ ! -d "$SRC" ]; then
  echo "Usage: $0 <folder_to_backup> [destination_folder]"
  exit 1
fi

mkdir -p "$DEST"
STAMP=$(date +%Y%m%d_%H%M%S)
FILE="$DEST/backup_$(basename "$SRC")_$STAMP.tar.gz"
tar -czf "$FILE" "$SRC" && echo "Backup created: $FILE"
