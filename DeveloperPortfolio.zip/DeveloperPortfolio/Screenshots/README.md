Put screenshots here, named clearly:
- q1_linux_terminal.png
- q1_system_info.png
- q2_system_info_output.png
- q2_backup_output.png
- q2_organizer_output.png
- q3_api_run.png
- q3_response_json.png
- q4_github_profile.png
- q4_linkedin.png
