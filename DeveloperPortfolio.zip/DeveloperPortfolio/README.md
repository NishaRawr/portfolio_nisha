# Beginner Developer Ecosystem Portfolio

**Author:** Nisha Rawat
**GitHub:** https://github.com/YOUR-USERNAME
**LinkedIn:** https://www.linkedin.com/in/YOUR-PROFILE

This repository is my capstone portfolio. It shows the skills I learned this semester across four labs: Linux, shell scripting, Git + APIs, and professional documentation/branding.

## Repository Structure

| Folder | Question | What's inside |
|---|---|---|
| `Linux/` | Q1 (CO1) | System profile and outputs of common Linux commands |
| `ShellScripts/` | Q2 (CO2) | Bash automation scripts |
| `API/` | Q3 (CO3) | Python script that calls a public API + saved JSON response |
| `Portfolio/` | Q4 (CO4) | Resume (PDF), learning roadmap, LinkedIn screenshot |
| `Screenshots/` | All | Proof screenshots for every section |

## Q1 - Linux
Commands for navigation, files, permissions, processes and system info, with their real outputs. See [`Linux/system_profile.md`](Linux/system_profile.md) and [`Linux/command_outputs.txt`](Linux/command_outputs.txt).

## Q2 - Shell Scripts
| Script | Purpose |
|---|---|
| `system_info.sh` | Prints user, OS, CPU, memory and disk usage |
| `backup.sh` | Creates a timestamped `.tar.gz` backup of a folder |
| `file_organizer.sh` | Sorts files in a folder into subfolders by extension |

Run with: `chmod +x *.sh && ./system_info.sh`

## Q3 - Git & API
`API/fetch_api.py` requests data from the GitHub public API and saves it to `API/response.json`.

```bash
pip install requests
python3 API/fetch_api.py YOUR-USERNAME
```

## Q4 - Portfolio
- [Resume (PDF)](Portfolio/resume.pdf)
- [Learning Roadmap](Portfolio/roadmap.md)
- LinkedIn screenshot: `Portfolio/linkedin_screenshot.png`

## What I Learned
- Navigating and documenting a Linux system from the terminal
- Automating tasks with Bash
- Using Git/GitHub and consuming REST APIs with Python
- Writing clear Markdown documentation and building a professional presence
