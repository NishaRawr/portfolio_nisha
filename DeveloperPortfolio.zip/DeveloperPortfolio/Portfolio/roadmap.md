# Learning Roadmap - Nisha Rawat

**Goal:** Become an AI/ML engineer.

## Phase 1: Foundations (Months 0-3)
- [x] Linux basics and the terminal
- [x] Bash scripting
- [x] Git and GitHub
- [ ] Python fundamentals (data types, loops, functions, OOP)
- [ ] Markdown documentation

## Phase 2: Core Skills (Months 3-6)
- [ ] Python libraries: NumPy, Pandas, Matplotlib
- [ ] Jupyter Notebook workflow
- [ ] SQL basics
- [ ] REST APIs with `requests`
- [ ] Math for ML: linear algebra, probability, statistics

## Phase 3: Machine Learning (Months 6-12)
- [ ] scikit-learn: regression, classification, clustering
- [ ] Model evaluation and data cleaning
- [ ] 2 end-to-end ML projects on GitHub
- [ ] Kaggle practice

## Phase 4: Specialization (Year 2)
- [ ] Deep learning with PyTorch or TensorFlow
- [ ] NLP or Computer Vision
- [ ] Deploy a model (Flask / Streamlit)
- [ ] Internship applications

## Resources
- Course material and Jupyter notebooks from class
- Kaggle Learn, freeCodeCamp, official Python docs
- Practice: build one small project a month and push it to GitHub
