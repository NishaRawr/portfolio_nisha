Save your LinkedIn profile screenshot in this folder as `linkedin_screenshot.png`.
Make sure it shows: photo, headline, About, Education, Skills.

Suggested headline: Aspiring AI/ML Engineer | Python | Linux | Git
