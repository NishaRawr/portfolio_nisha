"""Fetch a GitHub user profile from the public GitHub API and save the JSON.

Usage: python3 fetch_api.py <github-username>
"""
import json
import sys

import requests

username = sys.argv[1] if len(sys.argv) > 1 else "octocat"
url = f"https://api.github.com/users/{username}"

response = requests.get(url, timeout=10)
print("Status code:", response.status_code)
response.raise_for_status()

data = response.json()
with open("response.json", "w") as f:
    json.dump(data, f, indent=2)

print("Name        :", data.get("name"))
print("Public repos:", data.get("public_repos"))
print("Followers   :", data.get("followers"))
print("Saved full response to response.json")
