# System Profile

> Fill the values below from the output of `Linux/collect_info.sh` (it writes `command_outputs.txt`).

| Item | Value |
|---|---|
| Name | Nisha Rawat |
| Distribution / OS | (from `lsb_release -a`) |
| Kernel | (from `uname -r`) |
| Shell | (from `echo $SHELL`) |
| CPU | (from `lscpu`) |
| RAM | (from `free -h`) |
| Disk | (from `df -h`) |
| Environment | Ubuntu via WSL2 / Linux Mint / VM (write which one) |

## Commands I Used
| Command | What it does |
|---|---|
| `pwd` | Shows current directory |
| `ls -la` | Lists all files with details |
| `cd`, `mkdir`, `touch` | Navigate, create folders and files |
| `cp`, `mv`, `rm` | Copy, move, delete |
| `cat`, `less`, `head`, `tail` | View file contents |
| `chmod`, `chown` | Change permissions and ownership |
| `ps`, `top` | View running processes |
| `grep`, `find` | Search text and files |
| `uname -a`, `whoami`, `df -h`, `free -h` | System information |

## Notes
Write 3-4 lines about what was new or difficult for you while learning Linux.
