#!/bin/bash
# Collects outputs of common Linux commands into command_outputs.txt
OUT="command_outputs.txt"
: > "$OUT"
run() {
  echo "=== \$ $* ===" >> "$OUT"
  "$@" >> "$OUT" 2>&1
  echo "" >> "$OUT"
}
run whoami
run pwd
run date
run uname -a
run lsb_release -a
run echo "$SHELL"
run lscpu
run free -h
run df -h
run ls -la
run ps aux --sort=-%mem
run uptime
echo "Saved to $OUT"
